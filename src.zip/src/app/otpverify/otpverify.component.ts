import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otpverify',
  templateUrl: './otpverify.component.html',
  styleUrls: ['./otpverify.component.scss'],
})
export class OtpverifyComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
