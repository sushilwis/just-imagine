import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otpnextpart',
  templateUrl: './otpnextpart.component.html',
  styleUrls: ['./otpnextpart.component.scss'],
})
export class OtpnextpartComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
